"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import SiteHeader from "../components/SiteHeader";
import SiteFooter from "../components/SiteFooter";
import {
  contractExplorerUrl,
  shortAddress,
  siteConfig,
} from "../lib/config";

const API_BASE = "https://api.onchainhoodies.xyz";

const PING_OPENSEA_URL =
  `https://opensea.io/assets/robinhood/${siteConfig.pingAddress}`;

type NeighborName = "Builder" | "Collector" | "Flipper" | "HODLer";

type NeighborToken = {
  tokenId: number;
  name: string;
  image: string;
  hoodie: NeighborName;
};

type SearchResult = {
  tokenId: number;
  name?: string;
  image?: string;
  traits?: {
    hoodie?: string;
  };
};

type SearchResponse = {
  total: number;
  results: SearchResult[];
};

type MarketMetric = "floor" | "sales" | "volume" | "holders";
type MarketRange = "7D" | "30D" | "ALL";

type ChartPoint = {
  timestamp: number;
  label: string;
  floor: number;
  sales: number;
  volume: number;
  owners: number | null;
  averageSale: number | null;
  medianSale: number | null;
  highestSale: number | null;
  buyers: number | null;
  sellers: number | null;
};

type MarketSummary = {
  floor: number | null;
  floorCurrency: string;
  bestOffer: number | null;
  bestOfferCurrency: string;
  owners: number | null;
  totalVolume: number | null;
  totalSales: number | null;
};

type UnknownRecord = Record<string, unknown>;

const neighborTypes: NeighborName[] = [
  "Builder",
  "Collector",
  "Flipper",
  "HODLer",
];

const neighborFallbacks: Record<NeighborName, string> = {
  Builder: "/builder.png",
  Collector: "/collector.png",
  Flipper: "/flipper.png",
  HODLer: "/hodler.png",
};

const tools = [
  {
    label: "Live",
    title: "Hood Talk",
    copy: "Give your Hoodie a permanent on-chain voice.",
    href: "/hood-talk",
    action: "Open Hood Talk",
  },
  {
    label: "Live",
    title: "Hoodie Explorer",
    copy: "Explore traits, rarity, market data and on-chain ink.",
    href: "/tools/explorer",
    action: "Open explorer",
  },
  {
    label: "Live",
    title: "Grid Exporter",
    copy: "Turn the Hoodies in your wallet into one clean branded grid.",
    href: "/tools/export",
    action: "Open exporter",
  },
  {
    label: "New",
    title: "Collage Maker",
    copy: "Build animated Hoodie scenes with stickers, drawings and frames.",
    href: "/tools/collage",
    action: "Make a scene",
  },
  {
    label: "Live",
    title: "Hoodie Cam",
    copy: "See your surroundings through the black-and-green language of the Hood.",
    href: "/cam",
    action: "Open camera",
  },
  {
    label: "New",
    title: "Gym Builder",
    copy: "Turn any Hoodie into a gym bro using its raw on-chain PixelData.",
    href: "/tools/gym",
    action: "Enter the gym",
  },
];

type FaqLink = {
  label: string;
  href: string;
  external?: boolean;
};

type Faq = {
  question: string;
  answer: string;
  href?: string;
  linkLabel?: string;
  links?: FaqLink[];
};

const faqs: Faq[] = [
  {
    question: "What are OnChainHoodies?",
    answer:
      "OnChainHoodies is a collection of 6,000 1-bit Hoodies living as a fully on-chain neighborhood on Robinhood Chain. Each Hoodie has its own artwork, traits and identity inside a growing ecosystem of wallets, apps, tools and community builds.",
    href: "/tools/explorer",
    linkLabel: "Explore the Hoodies",
  },
  {
    question: "What does fully on-chain mean?",
    answer:
      "The data needed to reconstruct each Hoodie lives on-chain. Traits, PixelData and rendering are part of the on-chain system instead of depending on a traditional hosted image file.",
    href: "/tools/explorer",
    linkLabel: "Inspect a Hoodie",
  },
  {
    question: "What can I do with my Hoodie?",
    answer:
      "Your Hoodie can speak through Hood Talk, own assets through HoodWallet and use apps through HoodOS. MintOS lets a Hoodie mint supported public OpenSea drops, BuyOS lets it collect secondary NFTs, and the wider ecosystem adds tools, games and experiments around the collection.",
    href: "/hoodos",
    linkLabel: "Explore HoodOS",
  },
  {
    question: "What is Hood Talk?",
    answer:
      "Hood Talk gives a Hoodie a permanent on-chain voice. Each message becomes part of that Hoodie's public history and can be read through the site and the public API.",
    href: "/hood-talk",
    linkLabel: "Open Hood Talk",
  },
  {
    question: "What are HoodWallet and HoodOS?",
    answer:
      "HoodWallet is the on-chain account belonging to a Hoodie. It can hold ETH, $OCH, Ping and other assets. HoodOS is the capability and app layer built around that account, letting the Hoodie mint, collect and interact on-chain while the current Hoodie owner remains in control.",
    links: [
      {
        label: "Open HoodWallet",
        href: "/hoodwallet",
      },
      {
        label: "Explore HoodOS",
        href: "/hoodos",
      },
    ],
  },
  {
    question: "What is Ping?",
    answer:
      "Ping is the first matching asset a Hoodie can unlock through HoodWallet. The first activation makes the corresponding Ping claimable and it is delivered directly into that Hoodie's on-chain wallet.",
    links: [
      {
        label: "View Ping contract",
        href: contractExplorerUrl(siteConfig.pingAddress),
        external: true,
      },
      {
        label: "View Ping on OpenSea",
        href: PING_OPENSEA_URL,
        external: true,
      },
    ],
  },
  {
    question: "What is $OCH?",
    answer:
      "$OCH is the fixed-supply currency of the Hood. It is live on Robinhood Chain, powers HoodWallet activation and is designed to grow alongside real utility across HoodOS, community integrations and the wider Hoodie economy. Season 01 is complete and Season 02 focuses on builders extending HoodOS or creating meaningful $OCH utility.",
    href: "/och",
    linkLabel: "Explore the Hood Economy",
  },
  {
    question: "Can I build with OnChainHoodies?",
    answer:
      "Yes. OnChainHoodies is CC0 and the public API exposes collection, ownership, market and Hood Talk data. Builders can create around the wider ecosystem or go deeper by building HoodOS integrations that give Hoodies new capabilities or meaningful uses for $OCH.",
    links: [
      {
        label: "Open the Builder API",
        href: "/api",
      },
      {
        label: "Explore builders",
        href: "/builders",
      },
    ],
  },
  {
    question: "Where can I see community projects?",
    answer:
      "The Builders page is the wider ecosystem showcase for tools, games, visualizers, experiments and integrations created around OnChainHoodies. HoodOS is the app layer specifically for capabilities that the Hoodie itself can use.",
    href: "/builders",
    linkLabel: "See community builds",
  },
  {
    question: "Where can I follow what happens next?",
    answer:
      "Follow OnChainHoodies on X for shipped updates, announcements and new integrations. Join Discord to talk with holders and builders, share what you are working on and stay close to what is being built next.",
    links: [
      {
        label: "Follow on X",
        href: siteConfig.xUrl,
        external: true,
      },
      {
        label: "Join Discord",
        href: siteConfig.discordUrl,
        external: true,
      },
    ],
  },
];

const contracts = [
  {
    label: "Collection",
    address: siteConfig.collectionAddress,
  },
  {
    label: "Renderer",
    address: siteConfig.rendererAddress,
  },
  {
    label: "Pixel Data",
    address: siteConfig.pixelDataAddress,
  },
  {
    label: "Hood Talk",
    address: siteConfig.hoodTalkRegistryAddress,
  },
  {
    label: "HoodOS",
    address: siteConfig.hoodOSAddress,
  },
  {
    label: "HoodWallet",
    address: siteConfig.hoodWalletAddress,
  },
  {
    label: "Ping",
    address: siteConfig.pingAddress,
  },
  {
    label: "Ping Rewards",
    address: siteConfig.pingRewardVaultAddress,
  },
  {
    label: "Hood Delegation",
    address: siteConfig.hoodDelegationAddress,
  },
  {
    label: "Treasury Vault",
    address: siteConfig.treasuryVaultAddress,
  },
  {
    label: "$OCH",
    address: siteConfig.ochAddress,
  },
  {
    label: "Allocation Vault",
    address: siteConfig.ochAllocationVaultAddress,
  },
  {
    label: "Team Vesting",
    address: siteConfig.ochTeamVestingAddress,
  },
  {
    label: "Liquidity Locker",
    address: siteConfig.ochLiquidityLockerAddress,
  },
];

const metricLabels: Record<MarketMetric, string> = {
  floor: "Floor",
  sales: "Sales",
  volume: "Volume",
  holders: "Holders",
};

function isRecord(value: unknown): value is UnknownRecord {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function numberFrom(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;

  if (typeof value === "string") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }

  if (isRecord(value)) {
    for (const key of ["amount", "value", "eth", "price", "total"]) {
      const nested = numberFrom(value[key]);
      if (nested !== null) return nested;
    }
  }

  return null;
}

function stringFrom(value: unknown, fallback = "ETH") {
  return typeof value === "string" && value.trim() ? value : fallback;
}

function findValue(
  object: UnknownRecord,
  paths: string[][],
): unknown {
  for (const path of paths) {
    let current: unknown = object;

    for (const key of path) {
      if (!isRecord(current)) {
        current = undefined;
        break;
      }

      current = current[key];
    }

    if (current !== undefined && current !== null) return current;
  }

  return undefined;
}

function unwrapData(value: unknown): UnknownRecord {
  if (!isRecord(value)) return {};
  return isRecord(value.data) ? value.data : value;
}

function normalizeMarketSummary(value: unknown): MarketSummary {
  const data = unwrapData(value);

  const floorValue = findValue(data, [
    ["floor"],
    ["floorPrice"],
    ["floor_price"],
    ["collectionFloor"],
    ["total", "floor_price"],
    ["total", "floorPrice"],
  ]);

  const offerValue = findValue(data, [
    ["bestCollectionOffer"],
    ["bestOffer"],
    ["best_offer"],
    ["offers", "best"],
  ]);

  return {
    floor: numberFrom(floorValue),
    floorCurrency: stringFrom(
      findValue(data, [
        ["floor", "currency"],
        ["floor", "symbol"],
        ["floorCurrency"],
        ["floor_price_symbol"],
        ["total", "floor_price_symbol"],
      ]),
    ),
    bestOffer: numberFrom(offerValue),
    bestOfferCurrency: stringFrom(
      findValue(data, [
        ["bestCollectionOffer", "price", "currency"],
        ["bestCollectionOffer", "currency"],
        ["bestOffer", "price", "currency"],
        ["bestOffer", "currency"],
      ]),
      "WETH",
    ),
    owners: numberFrom(
      findValue(data, [
        ["owners"],
        ["ownerCount"],
        ["owner_count"],
        ["total", "owners"],
        ["total", "num_owners"],
      ]),
    ),
    totalVolume: numberFrom(
      findValue(data, [
        ["volume"],
        ["totalVolume"],
        ["total_volume"],
        ["total", "volume"],
      ]),
    ),
    totalSales: numberFrom(
      findValue(data, [
        ["sales"],
        ["totalSales"],
        ["total_sales"],
        ["total", "sales"],
        ["total", "count"],
      ]),
    ),
  };
}

function normalizeHistory(value: unknown): ChartPoint[] {
  const root = unwrapData(value);
  const source = Array.isArray(root.points) ? root.points : [];

  return source
    .filter(isRecord)
    .map((point) => {
      const date = typeof point.date === "string" ? point.date : null;
      if (!date) return null;

      const timestamp = Date.parse(`${date}T00:00:00Z`);
      if (!Number.isFinite(timestamp)) return null;

      return {
        timestamp,
        label: new Intl.DateTimeFormat("en", {
          month: "short",
          day: "numeric",
        }).format(new Date(timestamp)),
        floor: numberFrom(point.floor) ?? 0,
        sales: numberFrom(point.sales) ?? 0,
        volume: numberFrom(point.volume) ?? 0,
        owners: numberFrom(point.owners),
        averageSale: numberFrom(point.averageSale),
        medianSale: numberFrom(point.medianSale),
        highestSale: numberFrom(point.highestSale),
        buyers: numberFrom(point.buyers),
        sellers: numberFrom(point.sellers),
      };
    })
    .filter((point): point is ChartPoint => point !== null)
    .sort((left, right) => left.timestamp - right.timestamp);
}

function normalizeHoodie(value: string): NeighborName | null {
  const normalized = value.trim().toLowerCase();

  if (normalized === "builder") return "Builder";
  if (normalized === "collector") return "Collector";
  if (normalized === "flipper") return "Flipper";
  if (normalized === "hodler") return "HODLer";

  return null;
}

async function fetchRandomNeighbor(
  hoodie: NeighborName,
  signal?: AbortSignal,
): Promise<NeighborToken> {
  const params = new URLSearchParams({
    hoodie,
    limit: "1",
    offset: "0",
    sort: "token",
  });

  const firstResponse = await fetch(
    `${API_BASE}/v1/search?${params.toString()}`,
    {
      signal,
      cache: "no-store",
    },
  );

  if (!firstResponse.ok) {
    throw new Error(`Could not load ${hoodie} supply.`);
  }

  const firstData = (await firstResponse.json()) as SearchResponse;

  if (!Number.isFinite(firstData.total) || firstData.total < 1) {
    throw new Error(`No ${hoodie} Hoodies found.`);
  }

  const randomOffset = Math.floor(Math.random() * firstData.total);
  params.set("offset", String(randomOffset));

  const tokenResponse = await fetch(
    `${API_BASE}/v1/search?${params.toString()}`,
    {
      signal,
      cache: "no-store",
    },
  );

  if (!tokenResponse.ok) {
    throw new Error(`Could not load a random ${hoodie}.`);
  }

  const tokenData = (await tokenResponse.json()) as SearchResponse;
  const result = tokenData.results?.[0];

  if (!result || typeof result.tokenId !== "number") {
    throw new Error(`The ${hoodie} response was empty.`);
  }

  const resolvedHoodie =
    normalizeHoodie(result.traits?.hoodie ?? "") ?? hoodie;

  return {
    tokenId: result.tokenId,
    name: result.name ?? `OnChainHoodies #${result.tokenId}`,
    image:
      result.image ?? `${API_BASE}/images/${result.tokenId}.svg`,
    hoodie: resolvedHoodie,
  };
}

function compactNumber(value: number | null, digits = 2) {
  if (value === null) return "—";

  return new Intl.NumberFormat("en", {
    maximumFractionDigits: digits,
    notation: value >= 10000 ? "compact" : "standard",
  }).format(value);
}

function MarketChart({
  points,
  metric,
}: {
  points: ChartPoint[];
  metric: MarketMetric;
}) {
  const width = 1000;
  const height = 390;
  const paddingLeft = 56;
  const paddingRight = 24;
  const paddingTop = 28;
  const paddingBottom = 48;
  const chartWidth = width - paddingLeft - paddingRight;
  const chartHeight = height - paddingTop - paddingBottom;
  const isBarChart = metric === "sales" || metric === "volume";

  const visiblePoints =
    metric === "holders"
      ? points.filter((point) => point.owners !== null)
      : points;

  const getValue = (point: ChartPoint) => {
    if (metric === "holders") return point.owners ?? 0;
    return point[metric];
  };

  const values = visiblePoints.map(getValue);
  const rawMaximum = Math.max(...values, 0);
  const positiveValues = values.filter((value) => value > 0);

  const rawMinimum =
    metric === "floor" || metric === "holders"
      ? Math.min(...positiveValues, rawMaximum || 0)
      : 0;

  const isAutoZoomMetric = metric === "floor" || metric === "holders";
  const rawSpread = Math.max(rawMaximum - rawMinimum, 0);

  const minimumPadding = isAutoZoomMetric
    ? metric === "floor"
      ? Math.max(rawMaximum * 0.01, 0.00025)
      : Math.max(rawMaximum * 0.0025, 1)
    : 0;

  const spreadPadding = isAutoZoomMetric
    ? Math.max(rawSpread * 0.18, minimumPadding)
    : 0;

  const minimum = isAutoZoomMetric
    ? Math.max(0, rawMinimum - spreadPadding)
    : 0;

  const maximum = isAutoZoomMetric
    ? rawMaximum + spreadPadding
    : Math.max(rawMaximum, 1);

  const range = Math.max(
    maximum - minimum,
    isAutoZoomMetric ? minimumPadding * 2 : maximum * 0.08,
    0.000001,
  );

  const xForIndex = (index: number) =>
    visiblePoints.length <= 1
      ? paddingLeft + chartWidth / 2
      : paddingLeft +
        (index / (visiblePoints.length - 1)) * chartWidth;

  const yForValue = (value: number) =>
    paddingTop + chartHeight - ((value - minimum) / range) * chartHeight;

  const coordinates = visiblePoints.map((point, index) => ({
    x: xForIndex(index),
    y: yForValue(getValue(point)),
    value: getValue(point),
    point,
  }));

  const line = coordinates
    .map(({ x, y }) => `${x.toFixed(2)},${y.toFixed(2)}`)
    .join(" ");

  const barSlot =
    visiblePoints.length > 0 ? chartWidth / visiblePoints.length : chartWidth;

  const barWidth = Math.max(12, Math.min(86, barSlot * 0.58));

  const formatAxisValue = (value: number) => {
    if (metric === "sales" || metric === "holders") {
      return compactNumber(value, 0);
    }

    return compactNumber(value, value < 1 ? 4 : 2);
  };

  if (visiblePoints.length < (isBarChart ? 1 : 2)) {
    return (
      <div className="grid min-h-[390px] place-items-center border-2 border-[#ccff00] p-8 text-center">
        <div>
          <p className="text-sm uppercase tracking-[0.16em]">
            {metric === "holders"
              ? "Holder history starts now"
              : "Market history is loading"}
          </p>

          <p className="mt-3 max-w-md text-xs leading-relaxed opacity-60">
            {metric === "holders"
              ? "Historical owner counts cannot be reconstructed reliably. The hourly recorder is now building this chart forward."
              : "Live summary data remains available above."}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="border-2 border-[#ccff00] p-3 md:p-5">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        role="img"
        aria-label={`${metricLabels[metric]} market chart`}
        className="h-auto w-full overflow-visible"
      >
        {[0, 1, 2, 3, 4].map((step) => {
          const ratio = step / 4;
          const y = paddingTop + ratio * chartHeight;
          const axisValue = maximum - ratio * (maximum - minimum);

          return (
            <g key={step}>
              <line
                x1={paddingLeft}
                x2={paddingLeft + chartWidth}
                y1={y}
                y2={y}
                stroke="currentColor"
                strokeOpacity="0.16"
                strokeWidth="1"
              />

              <text
                x={paddingLeft - 12}
                y={y + 4}
                textAnchor="end"
                fill="currentColor"
                fillOpacity="0.52"
                fontSize="13"
              >
                {formatAxisValue(axisValue)}
              </text>
            </g>
          );
        })}

        {isBarChart ? (
          coordinates.map(({ x, y, value, point }, index) => {
            const baseline = paddingTop + chartHeight;
            const renderedHeight = Math.max(2, baseline - y);

            return (
              <g key={`${point.timestamp}-${index}`}>
                <rect
                  x={x - barWidth / 2}
                  y={baseline - renderedHeight}
                  width={barWidth}
                  height={renderedHeight}
                  fill="currentColor"
                  fillOpacity="0.92"
                >
                  <title>
                    {point.label}: {formatAxisValue(value)}
                    {metric === "sales" ? " sales" : " ETH"}
                  </title>
                </rect>

                <rect
                  x={x - barWidth / 2}
                  y={baseline - renderedHeight}
                  width={barWidth}
                  height={renderedHeight}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                />
              </g>
            );
          })
        ) : (
          <>
            <polyline
              points={line}
              fill="none"
              stroke="currentColor"
              strokeWidth="5"
              strokeLinejoin="miter"
              strokeLinecap="square"
            />

            {coordinates.map(({ x, y, value, point }, index) => (
              <circle
                key={`${point.timestamp}-${index}`}
                cx={x}
                cy={y}
                r="5"
                fill="currentColor"
              >
                <title>
                  {point.label}: {formatAxisValue(value)}
                  {metric === "floor"
                    ? " ETH"
                    : metric === "holders"
                      ? " holders"
                      : ""}
                </title>
              </circle>
            ))}
          </>
        )}

        {visiblePoints.map((point, index) => {
          const shouldShow =
            visiblePoints.length <= 8 ||
            index === 0 ||
            index === visiblePoints.length - 1 ||
            index % Math.ceil(visiblePoints.length / 6) === 0;

          if (!shouldShow) return null;

          return (
            <text
              key={`label-${point.timestamp}`}
              x={xForIndex(index)}
              y={height - 15}
              textAnchor="middle"
              fill="currentColor"
              fillOpacity="0.52"
              fontSize="12"
            >
              {point.label.toUpperCase()}
            </text>
          );
        })}
      </svg>
    </div>
  );
}

export default function Home() {
  const [neighbors, setNeighbors] = useState<
    Partial<Record<NeighborName, NeighborToken>>
  >({});

  const [loadingNeighbors, setLoadingNeighbors] = useState<
    Partial<Record<NeighborName, boolean>>
  >({});

  const [marketSummary, setMarketSummary] = useState<MarketSummary>({
    floor: null,
    floorCurrency: "ETH",
    bestOffer: null,
    bestOfferCurrency: "WETH",
    owners: null,
    totalVolume: null,
    totalSales: null,
  });

  const [marketPoints, setMarketPoints] = useState<ChartPoint[]>([]);

  const [marketMetric, setMarketMetric] =
    useState<MarketMetric>("floor");

  const [marketRange, setMarketRange] =
    useState<MarketRange>("30D");

  const [marketLoading, setMarketLoading] =
    useState(true);

  const [marketError, setMarketError] =
    useState(false);

  const refreshNeighbor = useCallback(
    async (
      hoodie: NeighborName,
      signal?: AbortSignal,
    ) => {
      setLoadingNeighbors((current) => ({
        ...current,
        [hoodie]: true,
      }));

      try {
        const nextNeighbor =
          await fetchRandomNeighbor(
            hoodie,
            signal,
          );

        setNeighbors((current) => ({
          ...current,
          [hoodie]: nextNeighbor,
        }));
      } catch (error) {
        if (
          error instanceof DOMException &&
          error.name === "AbortError"
        ) {
          return;
        }

        console.error(error);
      } finally {
        if (!signal?.aborted) {
          setLoadingNeighbors((current) => ({
            ...current,
            [hoodie]: false,
          }));
        }
      }
    },
    [],
  );

  useEffect(() => {
    const controller = new AbortController();

    void Promise.all(
      neighborTypes.map((hoodie) =>
        refreshNeighbor(
          hoodie,
          controller.signal,
        ),
      ),
    );

    return () => controller.abort();
  }, [refreshNeighbor]);

  useEffect(() => {
    const controller = new AbortController();

    async function loadMarket() {
      setMarketLoading(true);
      setMarketError(false);

      const historyRange =
        marketRange === "7D"
          ? "7d"
          : marketRange === "30D"
            ? "30d"
            : "all";

      try {
        const [
          summaryResponse,
          historyResponse,
        ] = await Promise.all([
          fetch(
            `${API_BASE}/v1/market/collection`,
            {
              signal: controller.signal,
              cache: "no-store",
            },
          ),
          fetch(
            `${API_BASE}/v1/market/history?range=${historyRange}`,
            {
              signal: controller.signal,
              cache: "no-store",
            },
          ),
        ]);

        if (!summaryResponse.ok) {
          throw new Error(
            "Market summary unavailable.",
          );
        }

        const summaryJson: unknown =
          await summaryResponse.json();

        setMarketSummary(
          normalizeMarketSummary(summaryJson),
        );

        if (historyResponse.ok) {
          const historyJson: unknown =
            await historyResponse.json();

          setMarketPoints(
            normalizeHistory(historyJson),
          );
        } else {
          setMarketPoints([]);
        }
      } catch (error) {
        if (
          error instanceof DOMException &&
          error.name === "AbortError"
        ) {
          return;
        }

        console.error(error);
        setMarketError(true);
      } finally {
        if (!controller.signal.aborted) {
          setMarketLoading(false);
        }
      }
    }

    void loadMarket();

    return () => controller.abort();
  }, [marketRange]);

  const activePoints = useMemo(() => {
    if (marketPoints.length <= 60) {
      return marketPoints;
    }

    const step = Math.ceil(
      marketPoints.length / 60,
    );

    return marketPoints.filter(
      (_, index) =>
        index % step === 0 ||
        index === marketPoints.length - 1,
    );
  }, [marketPoints]);

  const selectedMarketStats = useMemo(() => {
    const latestFloor =
      [...activePoints]
        .reverse()
        .find(
          (point) =>
            point.floor > 0,
        )?.floor ??
      marketSummary.floor;

    const latestOwners =
      [...activePoints]
        .reverse()
        .find(
          (point) =>
            point.owners !== null,
        )?.owners ??
      marketSummary.owners;

    const totalSales =
      activePoints.reduce(
        (sum, point) =>
          sum + point.sales,
        0,
      );

    const totalVolume =
      activePoints.reduce(
        (sum, point) =>
          sum + point.volume,
        0,
      );

    const totalBuyers =
      activePoints.reduce(
        (sum, point) =>
          sum +
          (point.buyers ?? 0),
        0,
      );

    const totalSellers =
      activePoints.reduce(
        (sum, point) =>
          sum +
          (point.sellers ?? 0),
        0,
      );

    const highestSale = Math.max(
      ...activePoints.map(
        (point) =>
          point.highestSale ?? 0,
      ),
      0,
    );

    const weightedAverageSale =
      totalSales > 0
        ? totalVolume / totalSales
        : null;

    return {
      latestFloor,
      latestOwners,
      totalSales,
      totalVolume,
      totalBuyers,
      totalSellers,
      highestSale,
      weightedAverageSale,
    };
  }, [
    activePoints,
    marketSummary.floor,
    marketSummary.owners,
  ]);

  const selectedMetricValue =
    marketMetric === "floor"
      ? selectedMarketStats.latestFloor
      : marketMetric === "sales"
        ? selectedMarketStats.totalSales
        : marketMetric === "volume"
          ? selectedMarketStats.totalVolume
          : selectedMarketStats.latestOwners;

  return (
    <main className="bg-[#ccff00] text-black">
      <SiteHeader />

      <section className="mx-auto flex min-h-screen max-w-[1440px] flex-col items-center justify-center px-6 pb-16 pt-28 text-center">
        <img
          src="/onchainhoodies.gif"
          alt="Animated OnChainHoodie"
          className="image-render-pixel mb-9 w-[220px] md:w-[350px]"
        />

        <h1 className="text-[clamp(4rem,12vw,10rem)] leading-[0.82] tracking-[-0.08em]">
          WELCOME TO
          <br />
          THE HOOD
        </h1>

        <p className="mt-10 max-w-xl text-lg leading-relaxed md:text-2xl">
          Fully on-chain Hoodies. One growing Hood.
        </p>

        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <a
            href="#builds"
            className="pixel-cta"
          >
            Explore the builds
          </a>

          <a
            href={siteConfig.openSeaUrl}
            target="_blank"
            rel="noreferrer"
            className="pixel-cta pixel-cta-dark"
          >
            View on OpenSea
          </a>
        </div>

        <div className="mt-16 grid w-full max-w-5xl grid-cols-2 border-2 border-black text-[10px] uppercase tracking-[0.16em] md:grid-cols-4">
          {[
            "6,000 Hoodies",
            siteConfig.chainName,
            "Fully On-Chain",
            "CC0",
          ].map((item) => (
            <div
              key={item}
              className="border-black p-4 even:border-l-2 md:border-l-2 md:first:border-l-0"
            >
              {item}
            </div>
          ))}
        </div>
      </section>

      <section
        id="collection"
        className="bg-black px-6 py-24 text-[#ccff00]"
      >
        <div className="mx-auto max-w-[1440px]">
          <div className="section-heading-row">
            <p>01 / Collection</p>
            <p>Meet the Hood</p>
          </div>

          <div className="mt-12 grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:items-end">
            <div>
              <h2 className="section-title">
                Four Hoodies.
                <br />
                One Hood.
              </h2>

              <p className="mt-8 max-w-xl text-lg leading-relaxed opacity-80 md:text-xl">
                Builders, Collectors, Flippers and
                HODLers. Familiar faces from the
                on-chain world, hand-drawn in 1-bit
                and stored fully on-chain.
              </p>

              <p className="mt-5 text-[10px] uppercase tracking-[0.16em] opacity-60">
                Tap a Hoodie to meet another.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              {neighborTypes.map((hoodie) => {
                const neighbor =
                  neighbors[hoodie];

                const isLoading =
                  loadingNeighbors[hoodie] ??
                  false;

                const image =
                  neighbor?.image ??
                  neighborFallbacks[hoodie];

                const tokenLabel =
                  neighbor
                    ? `#${neighbor.tokenId}`
                    : "Loading";

                return (
                  <button
                    key={hoodie}
                    type="button"
                    onClick={() =>
                      void refreshNeighbor(
                        hoodie,
                      )
                    }
                    disabled={isLoading}
                    aria-label={`Load another ${hoodie} Hoodie`}
                    className="border-2 border-[#ccff00] text-left disabled:cursor-wait disabled:opacity-70"
                  >
                    <div className="aspect-square overflow-hidden bg-[#ccff00]">
                      <img
                        src={image}
                        alt={
                          neighbor?.name ??
                          `${hoodie} OnChainHoodie`
                        }
                        className="image-render-pixel h-full w-full object-cover"
                      />
                    </div>

                    <div className="flex items-center justify-between gap-2 border-t-2 border-[#ccff00] p-3 text-[10px] uppercase tracking-[0.14em]">
                      <span>{hoodie}</span>
                      <span className="opacity-60">
                        {tokenLabel}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      <section
        id="market"
        className="bg-[#ccff00] px-6 py-24 text-black"
      >
        <div className="mx-auto max-w-[1440px]">
          <div className="section-heading-row border-black">
            <p>02 / Market</p>
            <p>Track the Hood</p>
          </div>

          <div className="mt-12 grid gap-10 lg:grid-cols-[0.7fr_1.3fr]">
            <div>
              <h2 className="section-title">
                Culture lives.
                <br />
                Markets move.
              </h2>

              <p className="mt-8 max-w-xl text-lg leading-relaxed opacity-75 md:text-xl">
                Follow floor, sales and volume
                directly from the OnChainHoodies
                market layer.
              </p>

              <div className="mt-9 grid grid-cols-2 border-l-2 border-t-2 border-black">
                {[
                  {
                    label: "Floor",
                    value: marketLoading
                      ? "..."
                      : `${compactNumber(
                          marketSummary.floor,
                          4,
                        )} ${
                          marketSummary.floorCurrency
                        }`,
                  },
                  {
                    label: "Best offer",
                    value: marketLoading
                      ? "..."
                      : `${compactNumber(
                          marketSummary.bestOffer,
                          4,
                        )} ${
                          marketSummary.bestOfferCurrency
                        }`,
                  },
                  {
                    label: "Owners",
                    value: marketLoading
                      ? "..."
                      : compactNumber(
                          marketSummary.owners,
                          0,
                        ),
                  },
                  {
                    label: "Total volume",
                    value: marketLoading
                      ? "..."
                      : `${compactNumber(
                          marketSummary.totalVolume,
                          2,
                        )} ETH`,
                  },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="border-b-2 border-r-2 border-black p-4"
                  >
                    <p className="text-[8px] uppercase tracking-[0.15em] opacity-55">
                      {stat.label}
                    </p>

                    <p className="mt-3 text-xl leading-none">
                      {stat.value}
                    </p>
                  </div>
                ))}
              </div>

              <a
                href={siteConfig.openSeaUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-5 inline-block text-[10px] uppercase tracking-[0.15em] underline underline-offset-4"
              >
                Trade on OpenSea ↗
              </a>
            </div>

            <div className="min-w-0">
              <div className="flex flex-col gap-3 border-2 border-black bg-black p-3 text-[#ccff00] md:flex-row md:items-center md:justify-between">
                <div className="flex flex-wrap">
                  {(
                    [
                      "floor",
                      "sales",
                      "volume",
                      "holders",
                    ] as MarketMetric[]
                  ).map((metric) => (
                    <button
                      key={metric}
                      type="button"
                      onClick={() =>
                        setMarketMetric(metric)
                      }
                      className={`border border-[#ccff00] px-4 py-3 text-[9px] uppercase tracking-[0.14em] ${
                        marketMetric === metric
                          ? "bg-[#ccff00] text-black"
                          : ""
                      }`}
                    >
                      {metricLabels[metric]}
                    </button>
                  ))}
                </div>

                <div className="flex">
                  {(
                    [
                      "7D",
                      "30D",
                      "ALL",
                    ] as MarketRange[]
                  ).map((range) => (
                    <button
                      key={range}
                      type="button"
                      onClick={() =>
                        setMarketRange(range)
                      }
                      className={`border border-[#ccff00] px-4 py-3 text-[9px] uppercase tracking-[0.14em] ${
                        marketRange === range
                          ? "bg-[#ccff00] text-black"
                          : ""
                      }`}
                    >
                      {range}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-black p-4 text-[#ccff00] md:p-6">
                <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
                  <div>
                    <p className="text-[8px] uppercase tracking-[0.16em] opacity-55">
                      {metricLabels[marketMetric]} ·{" "}
                      {marketRange} ·{" "}
                      {marketMetric === "sales" ||
                      marketMetric === "volume"
                        ? "Period total"
                        : "Latest"}
                    </p>

                    <p className="mt-2 text-4xl leading-none tracking-[-0.05em]">
                      {marketLoading
                        ? "..."
                        : compactNumber(
                            selectedMetricValue,
                            marketMetric ===
                              "floor"
                              ? 4
                              : 2,
                          )}

                      {!marketLoading &&
                      (marketMetric === "floor" ||
                        marketMetric ===
                          "volume")
                        ? " ETH"
                        : ""}
                    </p>
                  </div>

                  <p className="text-[8px] uppercase tracking-[0.13em] opacity-50">
                    Source · OpenSea via OCH API
                  </p>
                </div>

                {(marketMetric === "floor" ||
                  marketMetric ===
                    "holders") &&
                activePoints.length > 0 ? (
                  <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border border-[#ccff00] px-3 py-3 text-[8px] uppercase tracking-[0.13em]">
                    <span className="opacity-55">
                      Auto-zoomed to visible range
                    </span>

                    <span>
                      {marketMetric === "floor"
                        ? `${compactNumber(
                            Math.min(
                              ...activePoints
                                .map(
                                  (point) =>
                                    point.floor,
                                )
                                .filter(
                                  (value) =>
                                    value > 0,
                                ),
                            ),
                            4,
                          )} — ${compactNumber(
                            Math.max(
                              ...activePoints.map(
                                (point) =>
                                  point.floor,
                              ),
                            ),
                            4,
                          )} ETH`
                        : `${compactNumber(
                            Math.min(
                              ...activePoints
                                .map(
                                  (point) =>
                                    point.owners,
                                )
                                .filter(
                                  (
                                    value,
                                  ): value is number =>
                                    value !==
                                    null,
                                ),
                            ),
                            0,
                          )} — ${compactNumber(
                            Math.max(
                              ...activePoints
                                .map(
                                  (point) =>
                                    point.owners,
                                )
                                .filter(
                                  (
                                    value,
                                  ): value is number =>
                                    value !==
                                    null,
                                ),
                            ),
                            0,
                          )} holders`}
                    </span>
                  </div>
                ) : null}

                <div className="mb-4 grid grid-cols-2 border-l border-t border-[#ccff00] md:grid-cols-4">
                  {[
                    {
                      label: "Average sale",
                      value:
                        selectedMarketStats.weightedAverageSale ===
                        null
                          ? "—"
                          : `${compactNumber(
                              selectedMarketStats.weightedAverageSale,
                              4,
                            )} ETH`,
                    },
                    {
                      label: "Highest sale",
                      value: `${compactNumber(
                        selectedMarketStats.highestSale,
                        4,
                      )} ETH`,
                    },
                    {
                      label: "Buyers",
                      value: compactNumber(
                        selectedMarketStats.totalBuyers,
                        0,
                      ),
                    },
                    {
                      label: "Sellers",
                      value: compactNumber(
                        selectedMarketStats.totalSellers,
                        0,
                      ),
                    },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="border-b border-r border-[#ccff00] p-3"
                    >
                      <p className="text-[7px] uppercase tracking-[0.14em] opacity-50">
                        {item.label}
                      </p>

                      <p className="mt-2 text-sm">
                        {item.value}
                      </p>
                    </div>
                  ))}
                </div>

                {marketMetric ===
                  "holders" &&
                activePoints.every(
                  (point) =>
                    point.owners === null,
                ) ? (
                  <p className="mb-4 border border-[#ccff00] p-3 text-[8px] uppercase leading-relaxed tracking-[0.12em] opacity-60">
                    Holder history is recorded
                    from API v1.5 onward. Earlier
                    daily owner counts are
                    intentionally left blank rather
                    than estimated.
                  </p>
                ) : null}

                {marketError ? (
                  <div className="grid min-h-[390px] place-items-center border-2 border-[#ccff00] p-8 text-center">
                    Market data is temporarily
                    unavailable.
                  </div>
                ) : (
                  <MarketChart
                    points={activePoints}
                    metric={marketMetric}
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section
        id="och"
        className="bg-black px-6 py-24 text-[#ccff00]"
      >
        <div className="mx-auto max-w-[1440px]">
          <div className="section-heading-row">
            <p>03 / The Hood Economy</p>
            <p>$OCH / Live Economy</p>
          </div>

          <div className="mt-12 grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
            <div>
              <img
                src="/coin1.gif"
                alt="Animated OCH coin"
                className="image-render-pixel h-36 w-36 object-contain md:h-52 md:w-52"
              />

              <p className="mt-8 text-[10px] uppercase tracking-[0.18em] opacity-60">
                The Currency of the Hood
              </p>

              <h2 className="section-title mt-4">
                $OCH
                <br />
                Built for the Hood.
              </h2>

              <p className="mt-8 max-w-xl text-lg leading-relaxed opacity-75 md:text-xl">
                A fixed-supply ERC-20 powering HoodWallet activation,
                on-chain participation and a growing economy of apps,
                integrations and builders around the Hood.
              </p>

              <div className="mt-8 grid max-w-xl grid-cols-2 border-l border-t border-[#ccff00] text-[9px] uppercase tracking-[0.14em] sm:grid-cols-4">
                {[
                  ["Supply", "100M"],
                  ["Inflation", "None"],
                  ["Trading Tax", "0%"],
                  ["Status", "Live"],
                ].map(([label, value]) => (
                  <div
                    key={label}
                    className="border-b border-r border-[#ccff00] p-3"
                  >
                    <p className="opacity-50">
                      {label}
                    </p>

                    <p className="mt-2 text-base tracking-normal">
                      {value}
                    </p>
                  </div>
                ))}
              </div>

              <Link
                href="/och"
                className="mt-10 inline-block text-xs uppercase tracking-[0.18em] underline underline-offset-4"
              >
                Explore the live economy →
              </Link>
            </div>

            <div className="grid gap-10 md:grid-cols-[0.75fr_1.25fr] md:items-center">
              <div className="mx-auto aspect-square w-full max-w-[260px]">
                <svg
                  viewBox="0 0 240 240"
                  role="img"
                  aria-label="OCH allocation chart"
                  className="h-full w-full"
                >
                  <circle
                    cx="120"
                    cy="120"
                    r="86"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="30"
                    opacity="0.12"
                  />

                  <g transform="rotate(-90 120 120)">
                    {[
                      { dash: "30 70", offset: 0, opacity: 1 },
                      { dash: "35 65", offset: -30, opacity: 0.82 },
                      { dash: "20 80", offset: -65, opacity: 0.66 },
                      { dash: "5 95", offset: -85, opacity: 0.5 },
                      { dash: "5 95", offset: -90, opacity: 0.34 },
                      { dash: "5 95", offset: -95, opacity: 0.22 },
                    ].map((segment, index) => (
                      <circle
                        key={index}
                        cx="120"
                        cy="120"
                        r="86"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="30"
                        pathLength="100"
                        strokeDasharray={segment.dash}
                        strokeDashoffset={segment.offset}
                        strokeLinecap="butt"
                        opacity={segment.opacity}
                      />
                    ))}
                  </g>

                  <circle
                    cx="120"
                    cy="120"
                    r="58"
                    fill="black"
                    stroke="currentColor"
                    strokeWidth="1"
                  />

                  <text
                    x="120"
                    y="111"
                    textAnchor="middle"
                    fill="currentColor"
                    fontSize="10"
                    letterSpacing="2"
                  >
                    FIXED
                  </text>

                  <text
                    x="120"
                    y="137"
                    textAnchor="middle"
                    fill="currentColor"
                    fontSize="24"
                  >
                    100M
                  </text>
                </svg>
              </div>

              <div className="border-l-2 border-t-2 border-[#ccff00]">
                {[
                  ["Hoodies", "30%"],
                  ["Community Fund", "35%"],
                  ["Liquidity", "20%"],
                  ["Treasury", "5%"],
                  ["Robinhood Ecosystem", "5%"],
                  ["Team", "5%"],
                ].map(([label, value]) => (
                  <div
                    key={label}
                    className="flex items-center justify-between gap-4 border-b-2 border-r-2 border-[#ccff00] p-4"
                  >
                    <span className="text-sm md:text-base">
                      {label}
                    </span>

                    <span className="text-xl leading-none md:text-2xl">
                      {value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-10 grid border-l border-t border-[#ccff00] md:grid-cols-4">
            <div className="border-b border-r border-[#ccff00] p-4">
              <p className="text-[8px] uppercase tracking-[0.14em] opacity-50">
                Season 01
              </p>

              <p className="mt-2 text-xl">
                Complete
              </p>

              <p className="mt-2 text-xs leading-relaxed opacity-60">
                The first community season has closed.
              </p>
            </div>

            <div className="border-b border-r border-[#ccff00] p-4">
              <p className="text-[8px] uppercase tracking-[0.14em] opacity-50">
                Season 02
              </p>

              <p className="mt-2 text-xl">
                Builders
              </p>

              <p className="mt-2 text-xs leading-relaxed opacity-60">
                Supporting builders extending HoodOS or creating meaningful
                utility for $OCH.
              </p>
            </div>

            <div className="border-b border-r border-[#ccff00] p-4">
              <p className="text-[8px] uppercase tracking-[0.14em] opacity-50">
                HoodWallet
              </p>

              <p className="mt-2 text-xl">
                2,500 OCH
              </p>

              <p className="mt-2 text-xs leading-relaxed opacity-60">
                Current activation cost, with an integrated ETH → OCH swap
                when the owner is short.
              </p>
            </div>

            <div className="border-b border-r border-[#ccff00] p-4">
              <p className="text-[8px] uppercase tracking-[0.14em] opacity-50">
                First Activation
              </p>

              <p className="mt-2 text-xl">
                Matching Ping
              </p>

              <p className="mt-2 text-xs leading-relaxed opacity-60">
                Activate the Hoodie and unlock its matching Ping directly
                into HoodWallet.
              </p>
            </div>
          </div>

          <div className="mt-6 border border-[#ccff00] px-4 py-4 text-center text-[8px] uppercase leading-relaxed tracking-[0.14em] opacity-80">
            <span className="opacity-60">
              Official $OCH Contract ·{" "}
            </span>

            <a
              href={contractExplorerUrl(siteConfig.ochAddress)}
              target="_blank"
              rel="noreferrer"
              className="break-all underline underline-offset-4"
            >
              {siteConfig.ochAddress}
            </a>

            <span className="opacity-60">
              {" "}
              · Always verify the contract before interacting.
            </span>
          </div>
        </div>
      </section>

      <section
        id="ping"
        className="px-6 py-20 md:py-24"
      >
        <div className="mx-auto max-w-[1440px]">
          <div className="section-heading-row border-black">
            <p>04 / Ping</p>
            <p>The first HoodWallet asset</p>
          </div>

          <div className="mt-12 grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
            <div className="overflow-hidden border-2 border-black bg-black">
              <img
                src="/ping.gif"
                alt="Animated Ping collection"
                className="image-render-pixel aspect-square h-full w-full object-cover"
              />
            </div>

            <div>
              <p className="text-[9px] uppercase tracking-[0.18em] opacity-50">
                Hoodie #N → Ping #N
              </p>

              <h2 className="section-title mt-5">
                MEET
                <br />
                PING.
              </h2>

              <p className="mt-7 max-w-xl text-lg leading-relaxed opacity-75 md:text-xl">
                Ping is the first matching asset your Hoodie can unlock.
                The first activation makes its corresponding Ping claimable
                and sends it directly into that Hoodie&apos;s HoodWallet.
              </p>

              <div className="mt-8 grid max-w-xl grid-cols-2 border-l-2 border-t-2 border-black">
                {[
                  ["Relationship", "1 per Hoodie"],
                  ["Unlock", "First activation"],
                  ["Destination", "HoodWallet"],
                  ["Network", "Robinhood"],
                ].map(([label, value]) => (
                  <div
                    key={label}
                    className="border-b-2 border-r-2 border-black p-4"
                  >
                    <p className="text-[7px] uppercase tracking-[0.14em] opacity-50">
                      {label}
                    </p>
                    <p className="mt-2 text-sm uppercase">
                      {value}
                    </p>
                  </div>
                ))}
              </div>

              <div className="mt-7 flex flex-wrap gap-3">
                <Link
                  href="/hoodwallet"
                  className="pixel-cta pixel-cta-dark"
                >
                  Open HoodWallet
                </Link>

                <a
                  href={PING_OPENSEA_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="pixel-cta"
                >
                  View Ping on OpenSea ↗
                </a>
              </div>

              <div className="mt-7 border border-black p-4">
                <p className="text-[7px] uppercase tracking-[0.14em] opacity-50">
                  Ping contract
                </p>

                <a
                  href={contractExplorerUrl(siteConfig.pingAddress)}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-2 block break-all text-[9px] underline underline-offset-4"
                >
                  {siteConfig.pingAddress}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section
        id="builds"
        className="px-6 py-20 md:py-24"
      >
        <div className="mx-auto max-w-[1440px]">
          <div className="section-heading-row border-black">
            <p>05 / Things to do</p>
            <p>Use your Hoodie</p>
          </div>

          <div className="mt-10 grid border-l-2 border-t-2 border-black sm:grid-cols-2 lg:grid-cols-3">
            {tools.map(
              (tool, index) => (
                <article
                  key={tool.title}
                  className="flex min-h-[190px] flex-col justify-between border-b-2 border-r-2 border-black p-5 md:p-6"
                >
                  <div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-[8px] uppercase tracking-[0.16em] opacity-50">
                        {String(
                          index + 1,
                        ).padStart(
                          2,
                          "0",
                        )}
                      </span>

                      <span className="border border-black px-2 py-1 text-[8px] uppercase tracking-[0.13em]">
                        {tool.label}
                      </span>
                    </div>

                    <h3 className="mt-7 text-2xl leading-none tracking-[-0.04em] md:text-3xl">
                      {tool.title}
                    </h3>

                    <p className="mt-4 max-w-sm text-sm leading-relaxed opacity-70">
                      {tool.copy}
                    </p>
                  </div>

                  <Link
                    href={tool.href}
                    className="mt-6 text-[9px] uppercase tracking-[0.15em] underline underline-offset-4"
                  >
                    {tool.action} →
                  </Link>
                </article>
              ),
            )}
          </div>

          <div className="mt-5 flex flex-col gap-4 border-2 border-black bg-black p-5 text-[#ccff00] md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-[8px] uppercase tracking-[0.16em] opacity-50">
                Community ecosystem
              </p>

              <p className="mt-2 text-lg md:text-xl">
                These are only the front doors. See
                what the Hood is building.
              </p>
            </div>

            <Link
              href="/builders"
              className="pixel-cta shrink-0 border-[#ccff00] bg-[#ccff00] text-black"
            >
              Explore community builds →
            </Link>
          </div>
        </div>
      </section>

      <section
        id="hoodos"
        className="bg-black px-6 py-24 text-[#ccff00]"
      >
        <div className="mx-auto max-w-[1440px]">
          <div className="section-heading-row">
            <p>06 / HoodOS</p>
            <p>What can your Hoodie do?</p>
          </div>

          <div className="mt-12 grid gap-12 lg:grid-cols-[0.78fr_1.22fr] lg:items-end">
            <div>
              <p className="text-[9px] uppercase tracking-[0.18em] opacity-55">
                Hoodie capabilities
              </p>

              <h2 className="section-title mt-5">
                YOUR HOODIE
                <br />
                CAN ACT.
              </h2>

              <p className="mt-8 max-w-xl text-lg leading-relaxed opacity-78 md:text-xl">
                HoodWallet gives every Hoodie its own on-chain account.
                HoodOS is the app layer that gives that account things to do:
                mint, collect, hold assets and interact with the on-chain world
                as the Hoodie itself.
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <Link
                  href="/hoodos"
                  className="pixel-cta border-[#ccff00]"
                >
                  Explore HoodOS →
                </Link>

                <Link
                  href="/hoodwallet"
                  className="pixel-cta border-[#ccff00] bg-[#ccff00] text-black"
                >
                  Open HoodWallet →
                </Link>
              </div>
            </div>

            <div className="grid border-l-2 border-t-2 border-[#ccff00] sm:grid-cols-2">
              {[
                {
                  eyebrow: "Account",
                  title: "HoodWallet",
                  copy: "The deterministic on-chain account belonging to your Hoodie.",
                  href: "/hoodwallet",
                },
                {
                  eyebrow: "HoodOS / App 01",
                  title: "MintOS",
                  copy: "Mint supported Robinhood OpenSea public drops directly as your Hoodie.",
                  href: "/hoodos/mintos",
                },
                {
                  eyebrow: "HoodOS / App 02",
                  title: "BuyOS",
                  copy: "Browse secondary listings and collect NFTs directly into HoodWallet.",
                  href: "/hoodos/buyos",
                },
                {
                  eyebrow: "Open platform",
                  title: "Build for HoodOS",
                  copy: "Builders can add new capabilities and integrations for Hoodies to use.",
                  href: "/builders",
                },
              ].map((app) => (
                <Link
                  key={app.title}
                  href={app.href}
                  className="flex min-h-[220px] flex-col justify-between border-b-2 border-r-2 border-[#ccff00] p-5 transition-colors hover:bg-[#ccff00] hover:text-black md:p-6"
                >
                  <div>
                    <p className="text-[7px] uppercase tracking-[0.15em] opacity-50">
                      {app.eyebrow}
                    </p>

                    <h3 className="mt-5 text-2xl leading-none tracking-[-0.04em] md:text-3xl">
                      {app.title}
                    </h3>

                    <p className="mt-4 max-w-sm text-sm leading-relaxed opacity-65">
                      {app.copy}
                    </p>
                  </div>

                  <span className="mt-7 text-[8px] uppercase tracking-[0.15em] underline underline-offset-4">
                    Open →
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section
        id="builders"
        className="px-6 py-20 md:py-24"
      >
        <div className="mx-auto max-w-[1440px]">
          <div className="section-heading-row border-black">
            <p>07 / Builders</p>
            <p>Build in the Hood</p>
          </div>

          <div className="mt-10 grid gap-8 lg:grid-cols-[0.7fr_1.3fr] lg:items-end">
            <div>
              <h2 className="section-title">
                Build on
                <br />
                the Hood.
              </h2>

              <p className="mt-6 max-w-lg text-base leading-relaxed opacity-70 md:text-lg">
                Build with an open CC0 collection,
                use the public infrastructure or
                discover what the community is
                already creating around the Hood.
              </p>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <Link
                href="/api"
                className="flex min-h-[180px] flex-col justify-between border-2 border-black p-5 transition-opacity hover:opacity-85 md:p-6"
                style={{
                  backgroundColor:
                    "var(--black)",
                  color:
                    "var(--green)",
                }}
              >
                <div>
                  <p className="text-[8px] uppercase tracking-[0.16em] opacity-50">
                    Infrastructure
                  </p>

                  <h3 className="mt-5 text-3xl leading-none tracking-[-0.04em]">
                    Builder API
                  </h3>

                  <p className="mt-4 max-w-sm text-sm leading-relaxed opacity-65">
                    Open data and APIs for building
                    with the Hood.
                  </p>
                </div>

                <span className="mt-6 text-[9px] uppercase tracking-[0.15em] underline underline-offset-4">
                  Open API →
                </span>
              </Link>

              <Link
                href="/builders"
                className="flex min-h-[180px] flex-col justify-between border-2 border-black p-5 transition-opacity hover:opacity-85 md:p-6"
                style={{
                  backgroundColor:
                    "var(--black)",
                  color:
                    "var(--green)",
                }}
              >
                <div>
                  <p className="text-[8px] uppercase tracking-[0.16em] opacity-50">
                    Ecosystem
                  </p>

                  <h3 className="mt-5 text-3xl leading-none tracking-[-0.04em]">
                    Community Builds
                  </h3>

                  <p className="mt-4 max-w-sm text-sm leading-relaxed opacity-65">
                    Discover what other Hoodie
                    holders are shipping.
                  </p>
                </div>

                <span className="mt-6 text-[9px] uppercase tracking-[0.15em] underline underline-offset-4">
                  Explore builds →
                </span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section
        id="contracts"
        className="bg-black px-6 py-24 text-[#ccff00]"
      >
        <div className="mx-auto max-w-[1440px]">
          <div className="section-heading-row">
            <p>08 / On-chain</p>
            <p>Verify everything</p>
          </div>

          <div className="mt-12 grid gap-12 lg:grid-cols-[0.7fr_1.3fr]">
            <div>
              <h2 className="section-title">
                Contracts,
                <br />
                not promises.
              </h2>

              <p className="mt-8 max-w-lg text-lg leading-relaxed opacity-75">
                Collection data, rendering, HoodOS,
                $OCH and the protocol infrastructure
                live on-chain. Inspect the contracts
                and verify the Hood yourself.
              </p>

              <p className="mt-5 max-w-lg text-[9px] uppercase leading-relaxed tracking-[0.14em] opacity-50">
                Official OnChainHoodies contracts on{" "}
                {siteConfig.chainName}.
              </p>
            </div>

            <div className="border-l-2 border-t-2 border-[#ccff00]">
              {contracts.map(
                (contract) => {
                  const href =
                    contractExplorerUrl(
                      contract.address,
                    );

                  return (
                    <div
                      key={contract.label}
                      className="grid gap-3 border-b-2 border-r-2 border-[#ccff00] p-5 md:grid-cols-[180px_1fr_auto] md:items-center"
                    >
                      <span className="text-[10px] uppercase tracking-[0.16em] opacity-60">
                        {contract.label}
                      </span>

                      <code className="break-all text-sm">
                        {contract.address ||
                          "Coming soon"}
                      </code>

                      {href === "#" ? (
                        <span className="text-[10px] uppercase tracking-[0.14em] opacity-40">
                          {shortAddress(
                            contract.address,
                          )}
                        </span>
                      ) : (
                        <a
                          href={href}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[10px] uppercase tracking-[0.14em] underline underline-offset-4"
                        >
                          Explorer ↗
                        </a>
                      )}
                    </div>
                  );
                },
              )}
            </div>
          </div>
        </div>
      </section>

      <section
        id="faq"
        className="px-6 py-24"
      >
        <div className="mx-auto max-w-[1440px]">
          <div className="section-heading-row border-black">
            <p>09 / FAQ</p>
            <p>Read the Hood</p>
          </div>

          <div className="mt-12 grid gap-10 lg:grid-cols-[0.55fr_1.45fr]">
            <div>
              <h2 className="section-title">
                Know the Hood.
                <br />
                Go deeper.
              </h2>

              <p className="mt-7 max-w-md text-base leading-relaxed opacity-70">
                The essentials about the collection,
                what your Hoodie can do and where to
                explore next.
              </p>
            </div>

            <div className="border-t-2 border-black">
              {faqs.map(
                (faq, index) => (
                  <details
                    key={faq.question}
                    className="group border-b-2 border-black"
                  >
                    <summary className="flex cursor-pointer list-none items-center gap-4 py-5 md:py-6 [&::-webkit-details-marker]:hidden">
                      <span className="w-9 shrink-0 text-[8px] uppercase tracking-[0.15em] opacity-45">
                        {String(
                          index + 1,
                        ).padStart(
                          2,
                          "0",
                        )}
                      </span>

                      <span className="flex-1 text-sm uppercase tracking-[0.1em] md:text-base">
                        {faq.question}
                      </span>

                      <span className="text-2xl leading-none group-open:hidden">
                        +
                      </span>

                      <span className="hidden text-2xl leading-none group-open:inline">
                        −
                      </span>
                    </summary>

                    <div className="pb-6 pl-[52px] pr-10">
                      <p className="max-w-3xl text-sm leading-relaxed opacity-70 md:text-base">
                        {faq.answer}
                      </p>

                      {faq.links && faq.links.length > 0 ? (
                        <div className="mt-4 flex flex-wrap gap-x-5 gap-y-3">
                          {faq.links.map((item) =>
                            item.external ? (
                              <a
                                key={`${faq.question}-${item.label}`}
                                href={item.href}
                                target="_blank"
                                rel="noreferrer"
                                className="text-[9px] uppercase tracking-[0.15em] underline underline-offset-4"
                              >
                                {item.label} ↗
                              </a>
                            ) : (
                              <Link
                                key={`${faq.question}-${item.label}`}
                                href={item.href}
                                className="text-[9px] uppercase tracking-[0.15em] underline underline-offset-4"
                              >
                                {item.label} →
                              </Link>
                            ),
                          )}
                        </div>
                      ) : faq.href ? (
                        <Link
                          href={faq.href}
                          className="mt-4 inline-block text-[9px] uppercase tracking-[0.15em] underline underline-offset-4"
                        >
                          {faq.linkLabel} →
                        </Link>
                      ) : null}
                    </div>
                  </details>
                ),
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-black px-6 py-8 text-[#ccff00]">
        <div className="mx-auto grid max-w-[1440px] gap-6 border-y border-[#ccff00] py-7 lg:grid-cols-[1fr_auto] lg:items-center">
          <div>
            <p className="text-[9px] uppercase tracking-[0.18em] opacity-60">
              Stay in the Hood
            </p>

            <h2 className="mt-2 text-2xl leading-none tracking-[-0.04em] md:text-3xl">
              FOLLOW WHAT SHIPS.
            </h2>

            <p className="mt-3 max-w-2xl text-sm leading-relaxed opacity-70 md:text-base">
              Follow OnChainHoodies on X for announcements and shipped
              updates. Join Discord to meet holders, builders and the people
              extending the Hood.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row">
            <a
              href={siteConfig.xUrl}
              target="_blank"
              rel="noreferrer"
              className="pixel-cta shrink-0 border-[#ccff00]"
            >
              Follow on X ↗
            </a>

            <a
              href={siteConfig.discordUrl}
              target="_blank"
              rel="noreferrer"
              className="pixel-cta shrink-0 border-[#ccff00] bg-[#ccff00] text-black"
            >
              Join Discord ↗
            </a>
          </div>
        </div>
      </section>

      <SiteFooter />
    </main>
  );
}